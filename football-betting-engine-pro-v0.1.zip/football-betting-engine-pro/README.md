# Football Betting Engine PRO

Static MVP of a multi-day ACCA decision engine based on the principles of Football Final Engine v2.5.

## Current MVP

- Scans a configurable 48h / 72h / 7-day window.
- Selects 10–20 matches from one shared candidate pool.
- Uses Evidence Score rather than low odds as the main ranking signal.
- Checks model-vs-market disagreement.
- Limits concentration by league.
- Refuses to fill the ACCA with selections below the evidence threshold.
- Shows weakest leg, combined odds and estimated joint probability.

## Run locally

Because the project loads JSON through `fetch`, start a simple local web server:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Important

The included match data is synthetic demo data. It is not a betting recommendation and is only used to demonstrate the web application and engine logic.
