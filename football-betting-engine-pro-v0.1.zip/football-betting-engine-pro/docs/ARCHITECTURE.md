# Architecture v0.1

## Core pipeline

1. Fixture ingestion
2. Data-quality validation
3. Feature calculation
4. Match-model probability
5. Market implied probability / devig
6. Evidence Score
7. Risk and anomaly gates
8. Multi-day candidate ranking
9. ACCA portfolio optimisation
10. T-60 lineup revalidation
11. Lock / Watch / Remove / Replace lifecycle
12. Post-match calibration and audit log

## Evidence Score v0.1

- Data quality: 12
- Recent form: 14
- Home / away split: 10
- xG / xGA: 14
- Motivation: 10
- Lineup confidence: 10
- Injury information: 6
- Model agreement: 12
- Independent source consensus: 12

Total: 100.

Odds are not used as a simplistic quality filter. They are used for:
- implied probability;
- disagreement detection;
- devig and value checks;
- market-information review;
- combined ACCA calculation.

## Next engineering milestones

- Real fixture API adapter.
- League/team identity normalisation.
- Database and historical model store.
- Poisson/Dixon-Coles module.
- Devig module.
- Line-movement tracker.
- Source provenance and timestamps.
- Backtest/calibration dashboard.
- GitHub Actions data refresh.
