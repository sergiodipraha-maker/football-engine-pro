export function calculateEvidenceScore(match) {
  const weights = {
    dataQuality: 12,
    form: 14,
    homeAway: 10,
    xg: 14,
    motivation: 10,
    lineup: 10,
    injuries: 6,
    modelAgreement: 12,
    sourceConsensus: 12
  };

  return Object.entries(weights).reduce((total, [key, weight]) => {
    const value = Number(match.signals?.[key] ?? 0);
    return total + Math.max(0, Math.min(1, value)) * weight;
  }, 0);
}

export function marketImpliedProbability(decimalOdds) {
  return decimalOdds > 1 ? 1 / decimalOdds : 0;
}

export function disagreementFlag(match) {
  const market = marketImpliedProbability(match.odds);
  const gap = Math.abs(match.modelProbability - market);
  return {
    gap,
    flag: gap >= 0.18,
    label: gap >= 0.25 ? "CRITICAL REVIEW" : gap >= 0.18 ? "MARKET REVIEW" : "OK"
  };
}

export function buildAcca(matches, options) {
  const now = new Date();
  const cutoff = new Date(now.getTime() + options.windowHours * 60 * 60 * 1000);

  const eligible = matches
    .map(match => {
      const evidenceScore = calculateEvidenceScore(match);
      const disagreement = disagreementFlag(match);
      const kickoff = new Date(match.kickoff);

      let status = "LOCKED";
      if (match.dataStatus !== "confirmed" || disagreement.flag) status = "WATCH";
      if (evidenceScore < options.minEvidence) status = "REVIEW";

      return { ...match, evidenceScore, disagreement, kickoff, status };
    })
    .filter(match =>
      match.kickoff >= now &&
      match.kickoff <= cutoff &&
      match.evidenceScore >= options.minEvidence &&
      match.dataStatus !== "rejected"
    )
    .sort((a, b) => {
      const qualityA = a.evidenceScore * 0.65 + a.modelProbability * 100 * 0.35;
      const qualityB = b.evidenceScore * 0.65 + b.modelProbability * 100 * 0.35;
      return qualityB - qualityA;
    });

  const leagueCounts = new Map();
  const selected = [];

  for (const match of eligible) {
    const leagueCount = leagueCounts.get(match.league) ?? 0;
    if (leagueCount >= options.maxPerLeague) continue;
    if (selected.some(item => item.matchId === match.matchId)) continue;

    selected.push(match);
    leagueCounts.set(match.league, leagueCount + 1);
    if (selected.length >= options.targetLegs) break;
  }

  const combinedOdds = selected.reduce((product, item) => product * item.odds, 1);
  const estimatedProbability = selected.reduce(
    (product, item) => product * item.modelProbability,
    1
  );

  const weakestLeg = [...selected].sort((a, b) =>
    (a.evidenceScore + a.modelProbability * 100) -
    (b.evidenceScore + b.modelProbability * 100)
  )[0];

  return {
    selected,
    combinedOdds,
    estimatedProbability,
    weakestLeg,
    candidateCount: eligible.length
  };
}
