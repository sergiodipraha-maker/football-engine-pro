import { buildAcca } from "./engine.js";

const els = {
  buildButton: document.querySelector("#buildButton"),
  resetButton: document.querySelector("#resetButton"),
  windowHours: document.querySelector("#windowHours"),
  targetLegs: document.querySelector("#targetLegs"),
  minEvidence: document.querySelector("#minEvidence"),
  maxPerLeague: document.querySelector("#maxPerLeague"),
  rows: document.querySelector("#accaRows"),
  selectionCount: document.querySelector("#selectionCount"),
  combinedOdds: document.querySelector("#combinedOdds"),
  accaProbability: document.querySelector("#accaProbability"),
  riskLevel: document.querySelector("#riskLevel"),
  warnings: document.querySelector("#warnings"),
  windowLabel: document.querySelector("#windowLabel"),
  engineStatus: document.querySelector("#engineStatus")
};

let matches = [];

async function loadMatches() {
  const response = await fetch("./data/sample-matches.json");
  if (!response.ok) throw new Error("Не вдалося завантажити match data.");
  matches = await response.json();
}

function formatKickoff(value) {
  return new Intl.DateTimeFormat("uk-UA", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}

function riskLabel(probability, legs) {
  if (!legs) return "—";
  if (probability >= 0.12) return "HIGH";
  if (probability >= 0.04) return "VERY HIGH";
  return "EXTREME";
}

function render(result, hours) {
  els.selectionCount.textContent = result.selected.length;
  els.combinedOdds.textContent = result.selected.length
    ? result.combinedOdds.toFixed(2)
    : "—";
  els.accaProbability.textContent = result.selected.length
    ? `${(result.estimatedProbability * 100).toFixed(2)}%`
    : "—";
  els.riskLevel.textContent = riskLabel(
    result.estimatedProbability,
    result.selected.length
  );
  els.windowLabel.textContent = `${hours}h window`;

  if (!result.selected.length) {
    els.rows.innerHTML = `<tr><td colspan="9" class="empty">Немає достатньо сильних матчів у вибраному вікні.</td></tr>`;
    els.warnings.innerHTML = `<div class="warning">Engine не добирає слабкі матчі лише для заповнення ACCA.</div>`;
    return;
  }

  els.rows.innerHTML = result.selected.map((item, index) => `
    <tr>
      <td>${index + 1}</td>
      <td>${formatKickoff(item.kickoff)}</td>
      <td><strong>${item.home} — ${item.away}</strong></td>
      <td>${item.league}</td>
      <td>${item.market}<br><strong>${item.pick}</strong></td>
      <td>${item.odds.toFixed(2)}</td>
      <td>${(item.modelProbability * 100).toFixed(1)}%</td>
      <td class="score">${item.evidenceScore.toFixed(1)}</td>
      <td><span class="status ${item.status.toLowerCase()}">${item.status}</span></td>
    </tr>
  `).join("");

  const warnings = [];
  warnings.push(
    `<div class="warning"><strong>Weakest leg:</strong> ${result.weakestLeg.home} — ${result.weakestLeg.away}, ${result.weakestLeg.pick}, Evidence ${result.weakestLeg.evidenceScore.toFixed(1)}.</div>`
  );

  const marketReviews = result.selected.filter(item => item.disagreement.flag);
  if (marketReviews.length) {
    warnings.push(
      `<div class="warning"><strong>Market review:</strong> ${marketReviews.length} selection(s) мають велике розходження між моделлю та implied probability. Їх потрібно повторно перевірити перед LOCK.</div>`
    );
  }

  if (result.selected.length < Number(els.targetLegs.value)) {
    warnings.push(
      `<div class="warning"><strong>Incomplete ACCA:</strong> знайдено ${result.selected.length} із ${els.targetLegs.value}. Система не додала слабші picks.</div>`
    );
  }

  warnings.push(
    `<div class="warning"><strong>Risk note:</strong> навіть сильні окремі selections у великому ACCA множать загальний ризик. Estimated probability не є гарантією результату.</div>`
  );

  els.warnings.innerHTML = warnings.join("");
}

function build() {
  const options = {
    windowHours: Number(els.windowHours.value),
    targetLegs: Math.min(20, Math.max(10, Number(els.targetLegs.value))),
    minEvidence: Number(els.minEvidence.value),
    maxPerLeague: Number(els.maxPerLeague.value)
  };

  els.engineStatus.textContent = "ANALYSING";
  const result = buildAcca(matches, options);
  render(result, options.windowHours);
  els.engineStatus.textContent = "READY";
}

els.buildButton.addEventListener("click", build);
els.resetButton.addEventListener("click", () => {
  els.windowHours.value = "72";
  els.targetLegs.value = "15";
  els.minEvidence.value = "85";
  els.maxPerLeague.value = "4";
  build();
});

loadMatches()
  .then(build)
  .catch(error => {
    els.engineStatus.textContent = "ERROR";
    els.warnings.innerHTML = `<div class="warning">${error.message}</div>`;
  });
